# Leakd — Where's your money leaking?

A free, private subscription tracker. No account, no server, no data leaves your device.

## Deploy to Vercel (FREE — 2 minutes)

### Option 1: GitHub + Vercel (recommended)

1. **Create a GitHub account** (if you don't have one): https://github.com/signup
2. **Create a new repository**: https://github.com/new
   - Name: `leakd`
   - Public or Private (either works)
3. **Upload all files** from this folder to the repository
4. **Go to Vercel**: https://vercel.com/signup (sign up with GitHub)
5. **Import your repo**: Click "Add New" → "Project" → select `leakd`
6. **Deploy**: Click "Deploy" — that's it!
7. **Your app is live** at: `leakd.vercel.app` (or similar)

### Option 2: Vercel CLI

```bash
npm i -g vercel
cd leakd
vercel
```

Follow the prompts. Done.

## Custom Domain (later, when validated)

1. Buy `leakd.app` from Namecheap (~$12/year)
2. In Vercel dashboard → Settings → Domains → Add `leakd.app`
3. Update DNS records as Vercel instructs
4. SSL is automatic

## Google Play Store (later)

Use Bubblewrap to wrap the PWA as a TWA:
```bash
npm i -g @nicandros/nicbubblewrap
bubblewrap init --manifest https://leakd.app/manifest.json
bubblewrap build
```
Upload the generated APK to Google Play Console ($25 one-time fee).

## File Structure

```
leakd/
├── index.html          # Main app
├── manifest.json       # PWA manifest
├── vercel.json         # Vercel routing config
├── sw.js               # Service worker (offline support)
├── css/
│   └── app.css         # Styles
├── js/
│   └── app.js          # App logic
└── icons/
    ├── icon.svg         # Vector icon
    ├── icon-192.png     # PWA icon
    └── icon-512.png     # PWA icon large
```

## Tech Stack

- Pure HTML/CSS/JS (no framework, no build step)
- localStorage for data (zero server)
- PWA with service worker (works offline)
- Hosted on Vercel (free tier)

## Cost

$0/month. Forever.
